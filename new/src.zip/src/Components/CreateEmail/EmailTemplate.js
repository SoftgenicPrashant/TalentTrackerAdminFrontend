import React from 'react'

const EmailTemplate = () => {
  return (
    <div>
        
    </div>
  )
}

export default EmailTemplate